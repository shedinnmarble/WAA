
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author yafen
 */
@ManagedBean(name = "Login", eager = true)
@RequestScoped
public class Login {

    private String userName;
    private String pwd;
    private String msg;

    public Login() {
    }

    public String login() {
        if (this.userName.equals("k101") && pwd.equals("yoyo")) {
            this.msg = "Welcome Frank Brown";
        } else {
            this.msg = "Wrong userid or pwd";
        }
        return msg;
    }

    /**
     * @return the userName
     */
    public String getUserName() {
        return userName;
    }

    /**
     * @param userName the userName to set
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /**
     * @return the pwd
     */
    public String getPwd() {
        return pwd;
    }

    /**
     * @param pwd the pwd to set
     */
    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    /**
     * @return the msg
     */
    public String getMsg() {
        return msg;
    }

    /**
     * @param msg the msg to set
     */
    public void setMsg(String msg) {
        this.msg = msg;
    }

}
